CKEDITOR.plugins.setLang('attachment', 'en',
{
  attachment : 
  {
    title : "Insert attachment",
    url: "URL",
    name: "Title",
    button : "Insert attachment"
  }
});
